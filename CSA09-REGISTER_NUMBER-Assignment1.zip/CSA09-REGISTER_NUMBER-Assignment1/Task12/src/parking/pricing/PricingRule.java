package parking.pricing;

import java.time.LocalTime;

@FunctionalInterface
public interface PricingRule {
    double calculate(int minutes, LocalTime entryTime);
}
