package parking.service;

import parking.model.Vehicle;

public final class ParkingFacility {
    private final Vehicle[][] slots;

    public ParkingFacility(int[] slotsPerFloor) {
        slots = new Vehicle[slotsPerFloor.length][];
        for (int floor = 0; floor < slotsPerFloor.length; floor++) {
            if (slotsPerFloor[floor] <= 0) throw new IllegalArgumentException("invalid capacity");
            slots[floor] = new Vehicle[slotsPerFloor[floor]];
        }
    }

    public int[] allocate(Vehicle vehicle) {
        for (int floor = 0; floor < slots.length; floor++) {
            for (int slot = 0; slot < slots[floor].length; slot++) {
                if (slots[floor][slot] == null) {
                    slots[floor][slot] = vehicle;
                    return new int[]{floor, slot};
                }
            }
        }
        return null;
    }

    public void release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length || slot < 0 || slot >= slots[floor].length
                || slots[floor][slot] == null) {
            throw new IllegalArgumentException("invalid or empty slot");
        }
        slots[floor][slot] = null;
    }
}
