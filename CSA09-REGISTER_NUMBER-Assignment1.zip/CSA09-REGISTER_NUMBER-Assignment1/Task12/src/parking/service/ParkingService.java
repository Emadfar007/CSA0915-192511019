package parking.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import parking.model.Chargeable;
import parking.model.ParkingTicket;
import parking.model.User;
import parking.model.Vehicle;

public final class ParkingService {
    private final ParkingFacility facility;
    private final Map<String, ParkingTicket> activeTickets = new HashMap<>();

    public ParkingService(ParkingFacility facility) {
        this.facility = facility;
    }

    public ParkingTicket enter(Vehicle vehicle, User user, LocalDateTime entryTime) {
        String key = vehicle.getRegistrationNumber();
        if (activeTickets.containsKey(key)) throw new IllegalArgumentException("duplicate vehicle");
        int[] position = facility.allocate(vehicle);
        if (position == null) throw new IllegalStateException("facility is full");
        ParkingTicket ticket = new ParkingTicket(vehicle, user, position[0], position[1], entryTime);
        activeTickets.put(key, ticket);
        return ticket;
    }

    public double exit(String registrationNumber, int minutes, LocalDateTime exitTime) {
        return exit(registrationNumber, minutes, 0, exitTime);
    }

    public double exit(String registrationNumber, int minutes, int kWh, LocalDateTime exitTime) {
        ParkingTicket ticket = activeTickets.remove(registrationNumber.toUpperCase());
        if (ticket == null) throw new IllegalArgumentException("ticket not found");
        facility.release(ticket.floor(), ticket.slot());
        if (ticket.user().hasValidPass(exitTime.toLocalDate())) return 0.0;
        double amount = ticket.vehicle().calculateFee(minutes, ticket.entryTime().toLocalTime());
        if (ticket.vehicle() instanceof Chargeable chargeable) {
            amount += chargeable.chargingFee(kWh);
        }
        return amount;
    }
}
